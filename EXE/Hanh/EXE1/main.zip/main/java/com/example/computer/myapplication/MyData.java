package com.example.computer.myapplication;



public class MyData {

    static String[] nameArray = {"Cupcake", "Donut", "Eclair", "Froyo", "Gingerbread", "Honeycomb"};
    static String[] versionArray = {"Price: 299.000k", "Price: 199.000k", "Price: 499.000k", "Price: 99.000k", "Price: 799.000k", "Price: 699.000k"};

    static Integer[] drawableArray = {R.drawable.sp1, R.drawable.sp2, R.drawable.sp3,
            R.drawable.sp4, R.drawable.sp5, R.drawable.sp6};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5};
    static int selected_id = -1;
}
