package exe.ltdd2.test5;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button mapTDC1, mapTDC2, mapTDC3, mapTDC4, mapTDC5, mapTDC6;
    private String name;
    private Double v1;
    private Double v2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mapTDC1 = (Button) findViewById(R.id.mapTDC1);
        mapTDC2 = (Button) findViewById(R.id.mapTDC2);
        mapTDC3 = (Button) findViewById(R.id.mapTDC3);
        mapTDC4 = (Button) findViewById(R.id.mapTDC4);
        mapTDC5 = (Button) findViewById(R.id.mapTDC5);
        mapTDC6 = (Button) findViewById(R.id.mapTDC6);
        mapTDC1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = "Trường Cao Đẳng Công Nghệ Thủ Đức";
                v1 = 10.8521554;
                v2 = 106.7586514;
                map();
            }
        });
    }

    private void map() {
        try {
            Intent intent = new Intent(this, MapsActivity.class);
            intent.putExtra("name", name);
            intent.putExtra("v1", v1);
            intent.putExtra("v2", v2);
            this.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }
    }
}
