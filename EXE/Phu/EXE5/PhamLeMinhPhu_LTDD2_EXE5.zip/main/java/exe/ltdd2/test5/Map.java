package exe.ltdd2.test5;

public class Map {
    private String name;
    private Double v1;
    private Double v2;

    public Map(String name, Double v1, Double v2) {
        this.setName(name);
        this.setV1(v1);
        this.setV2(v2);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getV1() {
        return v1;
    }

    public void setV1(Double v1) {
        this.v1 = v1;
    }

    public Double getV2() {
        return v2;
    }

    public void setV2(Double v2) {
        this.v2 = v2;
    }
}
