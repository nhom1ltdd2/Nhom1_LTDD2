package com.example.android.musicapp.adapter;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import com.example.android.musicapp.Item;
import com.example.android.musicapp.R;

import java.util.ArrayList;

public class ListItemPlayingAdapter extends ArrayAdapter<Item> {
    private Activity context;
    private int layoutID;
    private ArrayList<Item> listItem;

    public ListItemPlayingAdapter(Activity context,int layoutID, ArrayList<Item> items){
        super(context, layoutID, items);
        this.context = context;
        this.layoutID = layoutID;
        this.listItem = items;
    }


    @NonNull
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null){
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.activity_list_playing, parent, false);

        }
        final CheckBox chkListItem = (CheckBox) listItemView.findViewById(R.id.chkCheck);
        Item listSong = listItem.get(position);
        Item currentItem= (Item) getItem(position);
        TextView firstLineTextView = (TextView) listItemView.findViewById(R.id.first_line_text_view);
        firstLineTextView.setText(currentItem.getFirstLine());
        TextView secondLineTextView = (TextView) listItemView.findViewById(R.id.second_line_text_view);
        secondLineTextView.setText(currentItem.getSecondLine());
        chkListItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (chkListItem.isChecked())
                {
                    listItem.get(position).setCheck(true);
                }else{
                    listItem.get(position).setCheck(false);
                }
            }
        });
        return listItemView;
    }
}
