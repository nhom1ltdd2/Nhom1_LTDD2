package com.example.android.musicapp;

/**
 * Created by ahmed on 2018-03-16.
 */

public class Item {
    /**
     * item first line
     */
    private String mFirstLine;

    /**
     * item second line
     */
    private String mSecondLine;

    /**
     * Create a new selection item
     *
     * @param firstLine song title
     * @param secondLine artisit name / Album title
     */
    private boolean check= false;

    public String getmFirstLine() {
        return mFirstLine;
    }

    public void setmFirstLine(String mFirstLine) {
        this.mFirstLine = mFirstLine;
    }

    public String getmSecondLine() {
        return mSecondLine;
    }

    public void setmSecondLine(String mSecondLine) {
        this.mSecondLine = mSecondLine;
    }

    public boolean isCheck() {
        return check;
    }

    public void setCheck(boolean check) {
        this.check = check;
    }

    public Item(String firstLine, String secondLine) {
        mFirstLine = firstLine;
        mSecondLine = secondLine;
    }



    /**
     * Get the first line of item
     */

    public String getFirstLine() {
        return mFirstLine;
    }

    /**
     * Get the second line of item
     */

    public String getSecondLine() {
        return mSecondLine;
    }
}