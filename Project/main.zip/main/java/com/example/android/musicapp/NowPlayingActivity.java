package com.example.android.musicapp;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Message;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.os.Handler;

import java.text.SimpleDateFormat;
import java.io.File;
import java.util.ArrayList;


public class NowPlayingActivity extends AppCompatActivity {
    private ImageView imvPlayRotate;
    private Button imvPause, imvNext, imvPrev;
    boolean isPause = false;
    TextView songTextLabel;
    private TextView tvTimeStart;
    private TextView tvTimeTotal;
    SeekBar songSeekbar;
    String sname;
    static MediaPlayer myMediaPlayer;
    int position;
    int totalTime;

    ArrayList<File> mySongs;
    Thread updateSeekbar;
    Dialog myDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playing_now);
        myDialog = new Dialog(this);
        imvNext = (Button)findViewById(R.id.next);
        imvPrev = (Button)findViewById(R.id.previous);
        imvPause = (Button)findViewById(R.id.pause);

        songTextLabel = (TextView) findViewById(R.id.item_first_line);
        tvTimeStart = (TextView) findViewById(R.id.tvStartSong) ;
        tvTimeTotal = (TextView) findViewById(R.id.tvTotaltSong);
        imvPlayRotate = (ImageView) findViewById(R.id.imgRotate);
        songSeekbar = (SeekBar) findViewById(R.id.seekBar);


//        getSupportActionBar().setTitle("Now playing");
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setDisplayShowHomeEnabled(true);




//        updateSeekbar = new Thread(){
//            @Override
//            public void run() {
//
//                int totalDuration = myMediaPlayer.getDuration();
//                int currentPosition = 0;
//
//                while(currentPosition<totalDuration){
//                    try{
//                        sleep(500);
//                        currentPosition = myMediaPlayer.getCurrentPosition();
//                        songSeekbar.setProgress(currentPosition);
//                    }
//                    catch (InterruptedException e){
//                        e.printStackTrace();
//                    }
//                }
//
//            }
//        };
        if(myMediaPlayer!=null){
            myMediaPlayer.stop();
            myMediaPlayer.release();
        }

        Intent i = getIntent();
        Bundle bundle = i.getExtras();

        mySongs = (ArrayList) bundle.getParcelableArrayList("songs");
        sname = mySongs.get(position).getName().toString();
        String songName = i.getStringExtra("songname");

        songTextLabel.setText(songName);
        songTextLabel.setSelected(true);

        position = bundle.getInt("pos", 0);

        Uri u = Uri.parse(mySongs.get(position).toString());

        myMediaPlayer = MediaPlayer.create(getApplicationContext(), u);

        myMediaPlayer.setLooping(true);
        myMediaPlayer.seekTo(0);

        totalTime = myMediaPlayer.getDuration();

        songSeekbar.setMax(totalTime);

        myMediaPlayer.start();

        songTextLabel.setText(mySongs.get(position).getName());

//        setTimeTotal();
//
//        updateTime();

        Animation aniRotateClk = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate_playing);

        imvPlayRotate.startAnimation(aniRotateClk);

//        songSeekbar.setMax(myMediaPlayer.getDuration());

//        updateSeekbar.start();

//        songSeekbar.getProgressDrawable().setColorFilter(getResources().getColor(R.color.category_artists), PorterDuff.Mode.MULTIPLY);
//
//        songSeekbar.getThumb().setColorFilter(getResources().getColor(R.color.category_artists), PorterDuff.Mode.SRC_IN);

//        songSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
//            @Override
//            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
//
//            }
//
//            @Override
//            public void onStartTrackingTouch(SeekBar seekBar) {
//
//            }
//
//            @Override
//            public void onStopTrackingTouch(SeekBar seekBar) {
//                myMediaPlayer.seekTo(seekBar.getProgress());
//            }
//        });

        imvPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                songSeekbar.setMax(myMediaPlayer.getDuration());

                if(myMediaPlayer.isPlaying()){
                    imvPause.setBackgroundResource(R.drawable.play);

                    myMediaPlayer.pause();
                }
                else {
//                    setTimeTotal();
                    songTextLabel.setText(mySongs.get(position).getName());

                    imvPause.setBackgroundResource(R.drawable.btn_pause);

//                    updateTime();

                    myMediaPlayer.start();
                }
            }
        });

        imvNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myMediaPlayer.stop();
                myMediaPlayer.release();
                position = ((position + 1)%mySongs.size());

                Uri u = Uri.parse(mySongs.get(position).toString());

                myMediaPlayer = MediaPlayer.create(getApplicationContext(), u);

                sname = mySongs.get(position).getName().toString();
                songTextLabel.setText(sname);

//                setTimeTotal();
//
//                updateTime();

                // Thread (Update positionBar & timeLabel)
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        while (myMediaPlayer != null) {
                            try {
                                Message msg = new Message();
                                msg.what = myMediaPlayer.getCurrentPosition();
                                handler.sendMessage(msg);
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {}
                        }
                    }
                }).start();

                myMediaPlayer.start();
            }
        });

        imvPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myMediaPlayer.stop();
                myMediaPlayer.release();

                position = ((position-1)<0)?(mySongs.size()-1):(position-1);
                Uri u = Uri.parse(mySongs.get(position).toString());
                myMediaPlayer = MediaPlayer.create(getApplicationContext(), u);

                sname = mySongs.get(position).getName().toString();
                songTextLabel.setText(sname);

//                setTimeTotal();
//
//                updateTime();

                // Thread (Update positionBar & timeLabel)
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        while (myMediaPlayer != null) {
                            try {
                                Message msg = new Message();
                                msg.what = myMediaPlayer.getCurrentPosition();
                                handler.sendMessage(msg);
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {}
                        }
                    }
                }).start();

                myMediaPlayer.start();

            }
        });
        songSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                if (b){
                    myMediaPlayer.seekTo(progress);
                    songSeekbar.setProgress(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        // Thread (Update positionBar & timeLabel)
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (myMediaPlayer != null) {
                    try {
                        Message msg = new Message();
                        msg.what = myMediaPlayer.getCurrentPosition();
                        handler.sendMessage(msg);
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {}
                }
            }
        }).start();

//        // get intent and extra values from others activity
//        Bundle extras = getIntent().getExtras();
//        if (extras != null) {
//            TextView itemFirstLine = (TextView)findViewById(R.id.item_first_line);
//            TextView itemSecondLine = (TextView)findViewById(R.id.item_second_line);
//            itemFirstLine.setText(extras.getString("FIRSTLINE"));
//            itemSecondLine.setText(extras.getString("SECONDLINE"));
//        }
//        imvPlay.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (isPause != true) {
//                    imvPlay.setVisibility(View.GONE);
//                    imvPause.setVisibility(View.VISIBLE);
//                    Animation aniRotateClk = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate_playing);
//                    imvPlayRotate.startAnimation(aniRotateClk);
//                }
//
//            }
//        });
//        imvPause.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                isPause = true;
//                imvPlay.setVisibility(View.VISIBLE);
//                imvPause.setVisibility(View.GONE);
//            }
//        });

    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            int currentPosition = msg.what;
            // Update positionBar.
            songSeekbar.setProgress(currentPosition);

            // Update Labels.
            String elapsedTime = createTimeLabel(currentPosition);
            tvTimeStart.setText(elapsedTime);

            String remainingTime = createTimeLabel(totalTime-currentPosition);
            tvTimeTotal.setText("- " + remainingTime);
        }
    };

    public String createTimeLabel(int time) {
        String timeLabel = "";
        int min = time / 1000 / 60;
        int sec = time / 1000 % 60;

        timeLabel = min + ":";
        if (sec < 10) timeLabel += "0";
        timeLabel += sec;

        return timeLabel;
    }

    public void ShowPopup(View v) {
        TextView txtclose;
        Button btnFollow;
        myDialog.setContentView(R.layout.custom_clock_popup);
        txtclose =(TextView) myDialog.findViewById(R.id.txtclose);
        txtclose.setText("M");
        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }
    // Cập nhật thời gian thực của bài đang phát
//    public void updateTime() {
//        final Handler handler = new Handler();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//
//                SimpleDateFormat formatHour = new SimpleDateFormat("mm:ss");
//                tvTimeStart.setText(formatHour.format(myMediaPlayer.getCurrentPosition()) + "");
//
//                // Cập nhật tiến trình seekbar
//                songSeekbar.setProgress(myMediaPlayer.getCurrentPosition());
//
//                // Kiểm tra thời gian bài hát
//                myMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
//                    @Override
//                    public void onCompletion(MediaPlayer mp) {
//                        position++;
//                        myMediaPlayer.stop();
//                        if (position > mySongs.size() - 1) {
//                            position = 0;
//                        }
//                        Uri u = Uri.parse(mySongs.get(position).toString());
//                        myMediaPlayer = MediaPlayer.create(getApplicationContext(), u);
//                        songTextLabel.setText(mySongs.get(position).getName());
//
//                        imvPause.setBackgroundResource(R.drawable.play);
//
//                        myMediaPlayer.start();
//                        setTimeTotal();
//                        updateTime();
//                    }
//                });
//
//                handler.postDelayed(this, 500);
//
//
//            }
//        }, 100);
//
//
//    }
    // Tính tổng thời gian của một bài hát
//    public void setTimeTotal() {
//        SimpleDateFormat formatHour = new SimpleDateFormat("mm:ss");
//
//        tvTimeTotal.setText(formatHour.format(myMediaPlayer.getDuration()) + "");
//
//        // Gán giá trị cho seekbar
//        songSeekbar.setMax(myMediaPlayer.getDuration());
//    }
}
